<?php

$server="localhost";
$user="root";
$password="";
$db="project1";

$con=mysqli_connect($server,$user,$password,$db);

?>

<?php
if(isset($_POST['submit']))
{
    $Name=$_POST['Name'];
    $number=$_POST['number'];
    $address=$_POST['address'];
    $email=$_POST['email'];
    $password=$_POST['password'];

    $res=mysqli_query($con,"INSERT into form values('$Name','$number','$address','$email','$password')");
    if($res)
    {
        echo "<script>alert('Successful')</script>";
        echo "<script>window.open('register.php')</script>";
    }
    else
    {
        echo "<script>alert('Invalid credentials..')</script>";
        echo "<script>window.open('register.php')</script>";
    }
}
?>