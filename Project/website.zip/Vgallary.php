<?php
include "home.php";
include "conection.php";
$sp=mysqli_query($con,"SELECT *from form");
?>


<table border="1">
    <?php
        while($res=mysqli_fetch_array($sp))
        {
            echo "<tr>";
            echo "<td>".$res['Name']."</td>";
            echo "<td>".$res['number']."</td>";
            echo "</tr>";
        }
    ?>
</table>